# -*- coding: utf-8 -*-

from models.vgg import *
from models.vgg_1 import *
#from dpn import *
#from lenet import *
#from senet import *
#from pnasnet import *
#from densenet import *
#from googlenet import *
#from shufflenet import *
from models.resnet import *
from models.resnet_1 import *
#from resnext import *
#from preact_resnet import *
#from mobilenet import *
#from mobilenetv2 import *