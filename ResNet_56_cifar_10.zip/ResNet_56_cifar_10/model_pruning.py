import torch
import torch.nn as nn
import numpy as np
import os
import math
import time
from torch.optim import Adam, SGD
from torch.optim.lr_scheduler import StepLR, ReduceLROnPlateau

def optimize_frobenius(F, k, max_iters=1500, lr=0.001, tol=1e-6, eps=1e-8):
    m, n = F.size()
    F = F / torch.norm(F, dim=0, keepdim=True)
    G1 = torch.randn(m,n, device=F.device)
    G = G1 @ G1.t()
    diag = torch.sqrt(torch.diag(G))
    G_normalized = G / (diag[:, None] * diag[None, :])
    temp  = int(k)
    epsilon = math.sqrt((n - temp) / (temp * (n - 1)))
    I = torch.clamp(G_normalized, min=-epsilon, max=epsilon)
    I.fill_diagonal_(1.0)

    # ---- Initialization: random positive values ----
    # x = torch.rand(n, requires_grad=True, device=F.device)
    x = torch.zeros(n, requires_grad=True, device=F.device)

    # Keep top-k active indices
    with torch.no_grad():
        _, idx = torch.topk(x, k)
        mask = torch.zeros_like(x)
        mask[idx] = 1.0
        x *= mask

    optimizer = Adam([x], lr=lr)
    scheduler = ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=50, verbose=False)
    loss_fro = []

    start_time1 = time.time()
    for epoch in range(max_iters):
        optimizer.zero_grad()
        X = torch.diag(x)
        loss = torch.norm(F @ X @ F.T - I, p="fro") ** 2
        loss.backward()
        optimizer.step()

        with torch.no_grad():
            # Ensure non-negativity
            x.clamp_(min=0.0)

            # Re-select the k largest values
            if k < len(x):
                _, idx = torch.topk(x, k)
                mask = torch.zeros_like(x)
                mask[idx] = 1.0
                x *= mask

            # Guarantee exactly k nonzeros by adding small epsilon
            # so that even if any of them hit zero, they're revived
            nonzero_idx = torch.nonzero(x).flatten()
            missing = k - len(nonzero_idx)
            if missing > 0:
                # Add small positive noise to randomly chosen zero entries
                zero_idx = torch.where(x == 0)[0]
                if len(zero_idx) >= missing:
                    extra_idx = zero_idx[torch.randperm(len(zero_idx))[:missing]]
                    x[extra_idx] = eps

        loss_fro.append(loss.item())
        scheduler.step(loss)
        if epoch % 500 == 0:
            current_time1 = time.time()
            elapsed_time1 = current_time1 - start_time1
            print(f"=====> Epoch: {epoch} | Optimizer Loss: {loss_fro[-1]:.8f} | Total Time Elapsed: {elapsed_time1:.4f}s")

        if loss.item() < tol:
            break

    # print(f"Final loss: {loss.item():.6f}, number of nonzeros = {(x>0).sum().item()}")
    end_t= time.time()
    tt_optimize = end_t-start_time1
    print(f"Total time for solving the optimization for the above layer is :{tt_optimize: .4f} seconds")
    return torch.diag(x)

#Autoencoder
import torch
import torch.nn as nn
import torch.nn.functional as F

class FilterVectorAutoencoder(nn.Module):
    def __init__(self, filter_dim, latent_dim=32):
        super().__init__()
        self.filter_dim = filter_dim
        self.latent_dim = latent_dim

        # Simple MLP AE – you can adjust sizes
        self.enc = nn.Sequential(
            nn.Linear(filter_dim, 4 * latent_dim),
            nn.ReLU(inplace=True),
            nn.Linear(4 * latent_dim, latent_dim)
        )

        self.dec = nn.Sequential(
            nn.Linear(latent_dim, 4 * latent_dim),
            nn.ReLU(inplace=True),
            nn.Linear(4 * latent_dim, filter_dim)
        )

    def encode(self, x):        # x: [N, filter_dim]
        return self.enc(x)      # -> [N, latent_dim]

    def forward(self, x):
        z = self.enc(x)
        recon = self.dec(z)
        return recon, z

def train_filter_autoencoder(F_flat, latent_dim=32, num_epochs=100, lr=1e-3, device=None):
    """
    F_flat: [num_filters, filter_dim] tensor (each row = one flattened filter)
    Train an AE to reconstruct these filters and return the trained model.
    """
    if device is None:
        device = F_flat.device

    num_filters, filter_dim = F_flat.shape

    ae = FilterVectorAutoencoder(filter_dim=filter_dim, latent_dim=latent_dim).to(device)
    optimizer = torch.optim.Adam(ae.parameters(), lr=lr)
    criterion = nn.MSELoss()

    F_flat = F_flat.to(device)

    ae.train()
    loss_ae = []
    start_time = time.time()
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        recon, _ = ae(F_flat)
        loss = criterion(recon, F_flat)
        loss.backward()
        optimizer.step()
        loss_ae.append(loss.detach().cpu().item())
    end_time = time.time()
    total_time = end_time-start_time
    print(f"Total Training Time: {total_time:.6f} seconds")

        # You can comment this out if too verbose
        # if (epoch + 1) % 50 == 0:
        #     print(f"[Filter AE] Epoch {epoch+1}/{num_epochs}, Loss: {loss.item():.6f}")

    return ae

def our_pruned_model_ae(model, prune_per, latent_dim=27,
                     ae_epochs=1000, ae_lr=1e-3):
    prev_out_channels = None  # To track the output channels of the previous layer
    non_zero_indices = None
    k = 1 - prune_per
    temp = 0
    all_losses = []

    # infer device
    device = next(model.parameters()).device

    for name, layer in model.features.named_children():
        if isinstance(layer, nn.Conv2d):
            weights = layer.weight.data.clone()      # [out_c, in_c, k_h, k_w]
            F = weights
            if non_zero_indices is not None:
                F = weights[:, non_zero_indices, :, :]  # restrict input channels

            num_filters = F.size(0)
            F_flat = F.view(num_filters, -1)           # [num_filters, filter_dim]

            # ---- NEW PART: train AE on these filters and get latent features ----
            with torch.no_grad():
                F_flat_norm = F_flat.clone()

            # Train AE to reconstruct filters (unsupervised)
            ae = train_filter_autoencoder(
                F_flat_norm.to(device),
                latent_dim=latent_dim,
                num_epochs=ae_epochs,
                lr=ae_lr,
                device=device
            )

            ae.eval()
            with torch.no_grad():
                z = ae.encode(F_flat_norm.to(device))      # [num_filters, latent_dim]
                z = z.cpu()

            # Build feature matrix with columns = filters
            # shape: [latent_dim, num_filters]
            feature_matrix = z.T

            # Use AE features instead of raw flattened filters
            X_updated = optimize_frobenius(
                feature_matrix,
                int(num_filters * k[temp])
            )

            temp = temp + 1

            # Select filters to keep
            non_zero_indices = (X_updated.diag() != 0).nonzero(as_tuple=True)[0]  # [kept_filters]

            pruned_filters = F[non_zero_indices]
            new_out_channels, new_in_channels, k_h, k_w = pruned_filters.shape

            # Update layer weights and dimensions
            layer.weight.data = pruned_filters.to(layer.weight.data.device)
            layer.out_channels = new_out_channels
            layer.in_channels = new_in_channels
            layer.bias.data = layer.bias[non_zero_indices]

            prev_out_channels = new_out_channels

        if isinstance(layer, nn.BatchNorm2d) and non_zero_indices is not None:
            weight = layer.weight.data.clone()
            bias = layer.bias.data.clone()
            rm = layer.running_mean.clone()
            rv = layer.running_var.clone()

            pruned_weight = weight[non_zero_indices]
            pruned_bias = bias[non_zero_indices]
            pruned_rm = rm[non_zero_indices]
            pruned_rv = rv[non_zero_indices]

            layer.weight = nn.Parameter(pruned_weight)
            layer.bias = nn.Parameter(pruned_bias)

            layer.running_mean = pruned_rm
            layer.running_var = pruned_rv

            layer.num_features = pruned_weight.shape[0]

    # ----- classifier pruning stays same -----
    for name, layer in model.classifier.named_children():
        if isinstance(layer, nn.Linear):
            W = layer.weight.data.clone()   # [out_features, in_features]
            W_t = W.t()                     # [in_features, out_features]

            W_t_pruned = W_t[non_zero_indices]
            W_pruned = W_t_pruned.t()

            layer.weight = nn.Parameter(W_pruned)
            layer.in_features = W_pruned.size(1)
            break

##################################################
##################################################



####################
#Code for both conv1 and conv2 pruning
import torch
import torch.nn as nn
from resnet_12 import LambdaLayer   # Your model uses this
# train_filter_autoencoder and optimize_frobenius must already exist


# ----------------------------------------------------------
# Build a Conv1×1 + BN shortcut PROPERLY on GPU
# ----------------------------------------------------------
def build_shortcut(inC, outC, stride, device):
    sc = nn.Sequential(
        nn.Conv2d(inC, outC, kernel_size=1, stride=stride, bias=False),
        nn.BatchNorm2d(outC)
    )
    return sc.to(device)


# ----------------------------------------------------------
# SAFETY CHECKER:
# Validates channel match after pruning
# ----------------------------------------------------------
def check_block_integrity(block, block_id):

    c1_in  = block.conv1.in_channels
    c1_out = block.conv1.out_channels

    c2_in  = block.conv2.in_channels
    c2_out = block.conv2.out_channels

    # Conv1 OUT == Conv2 IN
    if c1_out != c2_in:
        raise RuntimeError(
            f"[Integrity Error @ Block {block_id}] conv1_out={c1_out}, "
            f"but conv2_in={c2_in}"
        )

    # Shortcut output must match conv2 output
    if isinstance(block.shortcut, nn.Sequential) and len(block.shortcut) > 0:
        sc_out = block.shortcut[0].out_channels
    else:
        sc_out = c2_out  # identity

    if sc_out != c2_out:
        raise RuntimeError(
            f"[Integrity Error @ Block {block_id}] shortcut_out={sc_out}, "
            f"but conv2_out={c2_out}"
        )


# ----------------------------------------------------------
# FULL PRUNING FUNCTION (SAFE VERSION)
# ----------------------------------------------------------
def prune_resnet_filters(model, prune_rates,
                         latent_dim=27, ae_epochs=100, ae_lr=1e-3):

    device = next(model.parameters()).device
    conv_id = 0
    prev_keep = None

    # ------------------------------------------------------
    # 0) STEM CONV
    # ------------------------------------------------------
    stem = model.conv1
    W = stem.weight.data.clone().to(device)
    C_out = W.shape[0]

    prune_ratio = prune_rates[conv_id]
    keep_k = max(1, int(C_out * (1 - prune_ratio)))

    W_flat = W.view(C_out, -1)
    ae = train_filter_autoencoder(W_flat, latent_dim, ae_epochs, ae_lr, device)
    ae.eval()
    with torch.no_grad():
        Z = ae.encode(W_flat)
        F = Z.T

    st_opti = time.time()
    X = optimize_frobenius(F, keep_k)
    et_opti = time.time()
    tt_optimize = et_opti-st_opti
    print(f"{conv_id: .1f} th layer")
    #print(f"Total time for solving the optimization for the above layer is :{tt_optimize: .4f} seconds")
    keep_idx = (X.diag() != 0).nonzero(as_tuple=True)[0].cpu()

    # Apply pruning
    new_W = W[keep_idx]
    stem.weight = nn.Parameter(new_W)
    stem.out_channels = new_W.shape[0]

    # BN1 update
    bn1 = model.bn1
    bn1.weight = nn.Parameter(bn1.weight.data[keep_idx])
    bn1.bias   = nn.Parameter(bn1.bias.data[keep_idx])
    bn1.running_mean = bn1.running_mean[keep_idx]
    bn1.running_var  = bn1.running_var[keep_idx]
    bn1.num_features = len(keep_idx)

    prev_keep = keep_idx.clone()
    conv_id += 1

    # ------------------------------------------------------
    # 1) PRUNE ALL BLOCKS (3 stages × 9 blocks)
    # ------------------------------------------------------
    cfg = [9, 9, 9]
    block_count = 0

    for stage, num_blocks in enumerate(cfg):
        layer = getattr(model, f"layer{stage+1}")

        for b in range(num_blocks):
            block = layer[b]
            block_count += 1

            stride = block.stride

            # ==================================================
            # PRUNE CONV1 (OUT + IN)
            # ==================================================
            conv1 = block.conv1
            W1 = conv1.weight.data.clone().to(device)
            C_out1 = W1.shape[0]

            prune_ratio = prune_rates[conv_id]
            keep_k = max(1, int(C_out1 * (1 - prune_ratio)))

            W1_flat = W1.view(C_out1, -1)
            ae1 = train_filter_autoencoder(W1_flat, latent_dim, ae_epochs, ae_lr, device)
            ae1.eval()
            with torch.no_grad():
                Z1 = ae1.encode(W1_flat)
                F1 = Z1.T

            st_opti1 = time.time()
            X1 = optimize_frobenius(F1, keep_k)
            et_opti1 = time.time()
            tt_optimize = et_opti1-st_opti1
            print(f"{conv_id: .1f} th layer")
            #print(f"Total time for solving the optimization for the above layer is :{tt_optimize: .4f} seconds")
            keep_idx1 = (X1.diag() != 0).nonzero(as_tuple=True)[0].cpu()

            # OUT prune
            new_W1 = W1[keep_idx1]
            # IN prune
            new_W1 = new_W1[:, prev_keep, :, :]

            conv1.weight = nn.Parameter(new_W1)
            conv1.out_channels = new_W1.shape[0]
            conv1.in_channels  = new_W1.shape[1]

            # BN1 prune
            bn1 = block.bn1
            bn1.weight = nn.Parameter(bn1.weight.data[keep_idx1])
            bn1.bias   = nn.Parameter(bn1.bias.data[keep_idx1])
            bn1.running_mean = bn1.running_mean[keep_idx1]
            bn1.running_var  = bn1.running_var[keep_idx1]
            bn1.num_features = len(keep_idx1)

            prev_keep = keep_idx1.clone()
            conv_id += 1

            # ==================================================
            # PRUNE CONV2 (OUT + IN)
            # ==================================================
            conv2 = block.conv2
            W2 = conv2.weight.data.clone().to(device)
            C_out2 = W2.shape[0]

            prune_ratio2 = prune_rates[conv_id]
            keep_k2 = max(1, int(C_out2 * (1 - prune_ratio2)))

            W2_flat = W2.view(C_out2, -1)
            ae2 = train_filter_autoencoder(W2_flat, latent_dim, ae_epochs, ae_lr, device)
            ae2.eval()

            with torch.no_grad():
                Z2 = ae2.encode(W2_flat)
                F2 = Z2.T

            X2 = optimize_frobenius(F2, keep_k2)
            keep_idx2 = (X2.diag() != 0).nonzero(as_tuple=True)[0].cpu()

            # OUT prune
            new_W2 = W2[keep_idx2]
            # IN prune (from conv1)
            new_W2 = new_W2[:, prev_keep, :, :]

            conv2.weight = nn.Parameter(new_W2)
            conv2.out_channels = new_W2.shape[0]
            conv2.in_channels  = new_W2.shape[1]

            # BN2 prune
            bn2 = block.bn2
            bn2.weight = nn.Parameter(bn2.weight.data[keep_idx2])
            bn2.bias   = nn.Parameter(bn2.bias.data[keep_idx2])
            bn2.running_mean = bn2.running_mean[keep_idx2]
            bn2.running_var  = bn2.running_var[keep_idx2]
            bn2.num_features = len(keep_idx2)

            # New propagated index
            prev_keep = keep_idx2.clone()
            conv_id += 1

            # ==================================================
            # FIX SHORTCUT PROPERLY
            # ==================================================
            inC  = conv1.in_channels
            outC = conv2.out_channels

            need_proj = (inC != outC) or (stride != 1)

            if need_proj:
                block.shortcut = build_shortcut(inC, outC, stride, device)
            else:
                block.shortcut = nn.Sequential().to(device)

            # SAFETY CHECK
            check_block_integrity(block, block_count)

    # ------------------------------------------------------
    # 2) FIX FC LAYER
    # ------------------------------------------------------
    final_channels = prev_keep.shape[0]

    fc_old = model.fc
    new_fc = nn.Linear(final_channels, fc_old.out_features).to(device)

    new_fc.weight = nn.Parameter(fc_old.weight.data[:, prev_keep].clone().to(device))
    new_fc.bias   = nn.Parameter(fc_old.bias.data.clone().to(device))

    model.fc = new_fc

    print("✔ SAFE PRUNING COMPLETED (Shortcuts + FC + Integrity Checks OK)\n")



###############
###########################
def prune_resnet_filters_without_ae(model, prune_rates,
                         latent_dim=27, ae_epochs=100, ae_lr=1e-3):

    device = next(model.parameters()).device
    conv_id = 0
    prev_keep = None

    # ------------------------------------------------------
    # 0) STEM CONV
    # ------------------------------------------------------
    stem = model.conv1
    W = stem.weight.data.clone().to(device)
    C_out = W.shape[0]

    prune_ratio = prune_rates[conv_id]
    keep_k = max(1, int(C_out * (1 - prune_ratio)))

    W_flat = W.view(C_out, -1)
    F = W_flat.T
    st_opti = time.time()
    X = optimize_frobenius(F, keep_k)
    et_opti = time.time()
    tt_optimize = et_opti-st_opti
    print(f"{conv_id: .1f} th layer")
    keep_idx = (X.diag() != 0).nonzero(as_tuple=True)[0].cpu()

    # Apply pruning
    new_W = W[keep_idx]
    stem.weight = nn.Parameter(new_W)
    stem.out_channels = new_W.shape[0]

    # BN1 update
    bn1 = model.bn1
    bn1.weight = nn.Parameter(bn1.weight.data[keep_idx])
    bn1.bias   = nn.Parameter(bn1.bias.data[keep_idx])
    bn1.running_mean = bn1.running_mean[keep_idx]
    bn1.running_var  = bn1.running_var[keep_idx]
    bn1.num_features = len(keep_idx)

    prev_keep = keep_idx.clone()
    conv_id += 1

    # ------------------------------------------------------
    # 1) PRUNE ALL BLOCKS (3 stages × 9 blocks)
    # ------------------------------------------------------
    cfg = [9, 9, 9]
    block_count = 0

    for stage, num_blocks in enumerate(cfg):
        layer = getattr(model, f"layer{stage+1}")

        for b in range(num_blocks):
            block = layer[b]
            block_count += 1

            stride = block.stride

            # ==================================================
            # PRUNE CONV1 (OUT + IN)
            # ==================================================
            conv1 = block.conv1
            W1 = conv1.weight.data.clone().to(device)
            C_out1 = W1.shape[0]

            prune_ratio = prune_rates[conv_id]
            keep_k = max(1, int(C_out1 * (1 - prune_ratio)))

            W1_flat = W1.view(C_out1, -1)
            F1 = W1_flat.T
            st_opti1 = time.time()
            X1 = optimize_frobenius(F1, keep_k)
            et_opti1 = time.time()
            tt_optimize = et_opti1-st_opti1
            print(f"{conv_id: .1f} th layer")
            keep_idx1 = (X1.diag() != 0).nonzero(as_tuple=True)[0].cpu()

            # OUT prune
            new_W1 = W1[keep_idx1]
            # IN prune
            new_W1 = new_W1[:, prev_keep, :, :]

            conv1.weight = nn.Parameter(new_W1)
            conv1.out_channels = new_W1.shape[0]
            conv1.in_channels  = new_W1.shape[1]

            # BN1 prune
            bn1 = block.bn1
            bn1.weight = nn.Parameter(bn1.weight.data[keep_idx1])
            bn1.bias   = nn.Parameter(bn1.bias.data[keep_idx1])
            bn1.running_mean = bn1.running_mean[keep_idx1]
            bn1.running_var  = bn1.running_var[keep_idx1]
            bn1.num_features = len(keep_idx1)

            prev_keep = keep_idx1.clone()
            conv_id += 1

            # ==================================================
            # PRUNE CONV2 (OUT + IN)
            # ==================================================
            conv2 = block.conv2
            W2 = conv2.weight.data.clone().to(device)
            C_out2 = W2.shape[0]

            prune_ratio2 = prune_rates[conv_id]
            keep_k2 = max(1, int(C_out2 * (1 - prune_ratio2)))

            W2_flat = W2.view(C_out2, -1)
            F2 = W2_flat.T
            X2 = optimize_frobenius(F2, keep_k2)
            keep_idx2 = (X2.diag() != 0).nonzero(as_tuple=True)[0].cpu()

            # OUT prune
            new_W2 = W2[keep_idx2]
            # IN prune (from conv1)
            new_W2 = new_W2[:, prev_keep, :, :]

            conv2.weight = nn.Parameter(new_W2)
            conv2.out_channels = new_W2.shape[0]
            conv2.in_channels  = new_W2.shape[1]

            # BN2 prune
            bn2 = block.bn2
            bn2.weight = nn.Parameter(bn2.weight.data[keep_idx2])
            bn2.bias   = nn.Parameter(bn2.bias.data[keep_idx2])
            bn2.running_mean = bn2.running_mean[keep_idx2]
            bn2.running_var  = bn2.running_var[keep_idx2]
            bn2.num_features = len(keep_idx2)

            # New propagated index
            prev_keep = keep_idx2.clone()
            conv_id += 1

            # ==================================================
            # FIX SHORTCUT PROPERLY
            # ==================================================
            inC  = conv1.in_channels
            outC = conv2.out_channels

            need_proj = (inC != outC) or (stride != 1)

            if need_proj:
                block.shortcut = build_shortcut(inC, outC, stride, device)
            else:
                block.shortcut = nn.Sequential().to(device)

            # SAFETY CHECK
            check_block_integrity(block, block_count)

    # ------------------------------------------------------
    # 2) FIX FC LAYER
    # ------------------------------------------------------
    final_channels = prev_keep.shape[0]

    fc_old = model.fc
    new_fc = nn.Linear(final_channels, fc_old.out_features).to(device)

    new_fc.weight = nn.Parameter(fc_old.weight.data[:, prev_keep].clone().to(device))
    new_fc.bias   = nn.Parameter(fc_old.bias.data.clone().to(device))

    model.fc = new_fc

    print("✔ SAFE PRUNING COMPLETED (Shortcuts + FC + Integrity Checks OK)\n")
