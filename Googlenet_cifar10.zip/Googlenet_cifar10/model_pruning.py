import torch
import torch.nn as nn
import numpy as np
import os
import math
import time
from torch.optim import Adam, SGD
from torch.optim.lr_scheduler import StepLR, ReduceLROnPlateau



def optimize_frobenius(F, k, max_iters=1000, lr=0.001, tol=1e-6, eps=1e-8):
    m, n = F.size()
    F = F / torch.norm(F, dim=0, keepdim=True)
    
    #Uncomment for ETF code otherwise comment for Identity
    G1 = torch.randn(m,n, device=F.device)
    G = G1 @ G1.t()
    diag = torch.sqrt(torch.diag(G))
    G_normalized = G / (diag[:, None] * diag[None, :])
    temp  = int(k)
    epsilon = math.sqrt((n - temp) / (temp * (n - 1)))
    I = torch.clamp(G_normalized, min=-epsilon, max=epsilon)
    I.fill_diagonal_(1.0)


    #I = torch.eye(m, device=F.device)

    # ---- Initialization: random positive values ----
    # x = torch.rand(n, requires_grad=True, device=F.device)
    x = torch.zeros(n, requires_grad=True, device=F.device)

    # Keep top-k active indices
    with torch.no_grad():
        _, idx = torch.topk(x, k)
        mask = torch.zeros_like(x)
        mask[idx] = 1.0
        x *= mask

    optimizer = Adam([x], lr=lr)
    scheduler = ReduceLROnPlateau(optimizer, mode="min", factor=0.5, patience=50)
    loss_fro = []

    for _ in range(max_iters):
        optimizer.zero_grad()
        X = torch.diag(x)
        loss = torch.norm(F @ X @ F.T - I, p="fro") ** 2
        loss.backward()
        optimizer.step()

        with torch.no_grad():
            # Ensure non-negativity
            x.clamp_(min=0.0)

            # Re-select the k largest values
            if k < len(x):
                _, idx = torch.topk(x, k)
                mask = torch.zeros_like(x)
                mask[idx] = 1.0
                x *= mask

            # Guarantee exactly k nonzeros by adding small epsilon
            # so that even if any of them hit zero, they're revived
            nonzero_idx = torch.nonzero(x).flatten()
            missing = k - len(nonzero_idx)
            if missing > 0:
                # Add small positive noise to randomly chosen zero entries
                zero_idx = torch.where(x == 0)[0]
                if len(zero_idx) >= missing:
                    extra_idx = zero_idx[torch.randperm(len(zero_idx))[:missing]]
                    x[extra_idx] = eps

        loss_fro.append(loss.item())
        scheduler.step(loss)

        if loss.item() < tol:
            break

    # print(f"Final loss: {loss.item():.6f}, number of nonzeros = {(x>0).sum().item()}")
    return torch.diag(x)

#Autoencoder
import torch
import torch.nn as nn
import torch.nn.functional as F

class FilterVectorAutoencoder(nn.Module):
    def __init__(self, filter_dim, latent_dim=32):
        super().__init__()
        self.filter_dim = filter_dim
        self.latent_dim = latent_dim

        # Simple MLP AE – you can adjust sizes
        self.enc = nn.Sequential(
            nn.Linear(filter_dim, 4 * latent_dim),
            nn.ReLU(inplace=True),
            nn.Linear(4 * latent_dim, latent_dim)
        )

        self.dec = nn.Sequential(
            nn.Linear(latent_dim, 4 * latent_dim),
            nn.ReLU(inplace=True),
            nn.Linear(4 * latent_dim, filter_dim)
        )

    def encode(self, x):        # x: [N, filter_dim]
        return self.enc(x)      # -> [N, latent_dim]

    def forward(self, x):
        z = self.enc(x)
        recon = self.dec(z)
        return recon, z

def train_filter_autoencoder(F_flat, latent_dim=27, num_epochs=500, lr=1e-3, device=None):
    """
    F_flat: [num_filters, filter_dim] tensor (each row = one flattened filter)
    Train an AE to reconstruct these filters and return the trained model.
    """
    if device is None:
        device = F_flat.device

    num_filters, filter_dim = F_flat.shape

    ae = FilterVectorAutoencoder(filter_dim=filter_dim, latent_dim=latent_dim).to(device)
    optimizer = torch.optim.Adam(ae.parameters(), lr=lr)
    criterion = nn.MSELoss()

    F_flat = F_flat.to(device)

    ae.train()
    loss_ae = []
    start_time = time.time()
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        recon, _ = ae(F_flat)
        loss = criterion(recon, F_flat)
        loss.backward()
        optimizer.step()
        loss_ae.append(loss.detach().cpu().item())
    end_time = time.time()
    total_time = end_time-start_time
    print(f"Total Training Time: {total_time:.6f} seconds")

        # You can comment this out if too verbose
        # if (epoch + 1) % 50 == 0:
        #     print(f"[Filter AE] Epoch {epoch+1}/{num_epochs}, Loss: {loss.item():.6f}")

    return ae



def _prune_conv_and_bn(conv, bn, keep_idx_out, keep_idx_in, device):
    """Prune conv.weight, conv.bias (if exists), and BN parameters safely."""
    W = conv.weight.data.clone().to(device)      # [C_out, C_in, k, k]

    # OUT prune
    W_new = W[keep_idx_out]                      # [new_out, C_in, k, k]

    # IN prune
    W_new = W_new[:, keep_idx_in, :, :]          # [new_out, new_in, k, k]

    conv.weight = nn.Parameter(W_new)
    conv.out_channels = W_new.shape[0]
    conv.in_channels  = W_new.shape[1]

    # ---- FIX BIAS (This was missing!) ----
    if conv.bias is not None:
        old_bias = conv.bias.data.clone().to(device)   # [C_out_old]
        new_bias = old_bias[keep_idx_out]              # prune bias same as OUT filters
        conv.bias = nn.Parameter(new_bias)

    # ---- FIX BN (same as before) ----
    bn.weight = nn.Parameter(bn.weight.data[keep_idx_out].clone().to(device))
    bn.bias   = nn.Parameter(bn.bias.data[keep_idx_out].clone().to(device))
    bn.running_mean = bn.running_mean[keep_idx_out].clone().to(device)
    bn.running_var  = bn.running_var[keep_idx_out].clone().to(device)
    bn.num_features = len(keep_idx_out)


def prune_googlenet_filters(model, prune_rates,
                            latent_dim=40, ae_epochs=400, ae_lr=1e-3):
    """
    Prune GoogLeNet (CIFAR) following AE + Frobenius strategy.
    prune_rates: list/1D-tensor of length 64 (see message above for ordering).
    """
    device = next(model.parameters()).device
    dtype = next(model.parameters()).dtype

    conv_id = 0

    # ---------- 0) Pre-stem conv ----------
    stem = model.pre_layers[0]   # Conv2d(3, 192, ...)
    W = stem.weight.data.clone().to(device)
    C_out = W.shape[0]

    prune_ratio = float(prune_rates[conv_id])
    keep_k = max(1, int(C_out * (1 - prune_ratio)))

    # AE on filters (same as your ResNet flow)
    W_flat = W.view(C_out, -1)
    ae = train_filter_autoencoder(W_flat, latent_dim, ae_epochs, ae_lr, device)
    ae.eval()
    with torch.no_grad():
        Z = ae.encode(W_flat)
        F = Z.T

    X = optimize_frobenius(F, keep_k)
    keep_idx = (X.diag() != 0).nonzero(as_tuple=True)[0].to(device)

    # apply stem pruning
    new_W = W[keep_idx]
    stem.weight = nn.Parameter(new_W.to(dtype))
    stem.out_channels = new_W.shape[0]

    # update BN in pre_layers (assumes pre_layers[1] is BN)
    bn_stem = model.pre_layers[1]
    bn_stem.weight = nn.Parameter(bn_stem.weight.data[keep_idx].clone().to(device))
    bn_stem.bias   = nn.Parameter(bn_stem.bias.data[keep_idx].clone().to(device))
    bn_stem.running_mean = bn_stem.running_mean[keep_idx].clone().to(device)
    bn_stem.running_var  = bn_stem.running_var[keep_idx].clone().to(device)
    bn_stem.num_features = len(keep_idx)

    prev_total = new_W.shape[0]
    # After pruning the stem, the concatenated output channels for the first inception
    # is prev_total. For indexing the next module's first-conv IN selection we will
    # define prev_keep as range(prev_total)
    prev_keep = torch.arange(prev_total, device=device)

    conv_id += 1

    # ---------- 1) Prune Inception modules ----------
    # We assume module attribute names like model.inception_a3, model.inception_b3, ...
    # We'll collect them in the order they appear in the model's forward (as printed).
    inception_names = [
        "inception_a3", "inception_b3",
        "inception_a4", "inception_b4", "inception_c4", "inception_d4", "inception_e4",
        "inception_a5", "inception_b5"
    ]

    for name in inception_names:
        inception = getattr(model, name)
        # keep track of each branch's output keep indices and sizes (for concatenation)
        branch_keeps = []

        # branches in the order: branch1x1, branch3x3, branch5x5, branch_pool
        for branch in ["branch1x1", "branch3x3", "branch5x5", "branch_pool"]:
            seq = getattr(inception, branch)
            # seq is a Sequential containing Conv, BN, ReLU, maybe multiple convs
            # we'll iterate and process each Conv2d found in order
            branch_prev_keep = prev_keep.clone()  # first conv in branch uses prev_keep for IN selection
            branch_last_keep = None

            for module in seq:
                if isinstance(module, nn.Conv2d):
                    Wb = module.weight.data.clone().to(device)
                    C_outb = Wb.shape[0]

                    prune_ratio_b = float(prune_rates[conv_id])
                    keep_k_b = max(1, int(C_outb * (1 - prune_ratio_b)))

                    Wb_flat = Wb.view(C_outb, -1)
                    ae_b = train_filter_autoencoder(Wb_flat, latent_dim, ae_epochs, ae_lr, device)
                    ae_b.eval()
                    with torch.no_grad():
                        Zb = ae_b.encode(Wb_flat)
                        Fb = Zb.T

                    Xb = optimize_frobenius(Fb, keep_k_b)
                    keep_idx_out = (Xb.diag() != 0).nonzero(as_tuple=True)[0].to(device)

                    # prune IN: for first conv in branch use branch_prev_keep; else use branch_last_keep
                    if branch_last_keep is None:
                        keep_idx_in = branch_prev_keep
                    else:
                        keep_idx_in = branch_last_keep

                    # apply pruning to conv and the following BN (we'll find BN by index)
                    # find the BN that follows this conv in seq
                    # Save BN reference:
                    # Note: we will update BN when encountered (else try to find next BN in seq),
                    # but simpler: find bn by scanning seq and matching first BatchNorm2d after this conv.
                    # We'll update BN after we prune conv (below)
                    # find bn index:
                    bn_ref = None
                    found_conv = False
                    # scan sequential to find BN after this conv module object
                    conv_seen = False
                    for m in seq:
                        if m is module:
                            conv_seen = True
                            continue
                        if conv_seen and isinstance(m, nn.BatchNorm2d):
                            bn_ref = m
                            break

                    # apply pruning using helper
                    if bn_ref is None:
                        raise RuntimeError(f"No BN found after conv in branch {branch} of {name}")

                    _prune_conv_and_bn(module, bn_ref, keep_idx_out, keep_idx_in, device)

                    # remember branch_last_keep for next conv-in-prune
                    branch_last_keep = keep_idx_out.clone()
                    conv_id += 1

                else:
                    # non-conv layers: BN/Relu/Pool — ignore here
                    continue

            # after finishing the branch, branch_last_keep holds the kept indices in that branch (relative)
            if branch_last_keep is None:
                # branch had no conv (shouldn't happen), assume zero channels
                branch_keeps.append(torch.tensor([], dtype=torch.long, device=device))
            else:
                branch_keeps.append(branch_last_keep)

        # After pruning all branches, we must form the new concatenated channel layout for this inception output.
        # The new total out channels = sum(len(k) for k in branch_keeps)
        # We'll reindex them as contiguous 0..(total-1) for the next module.
        out_sizes = [len(k) for k in branch_keeps]
        total_out = sum(out_sizes)
        if total_out == 0:
            raise RuntimeError(f"Inception {name} produced zero output channels after pruning!")

        # Build new prev_keep as contiguous indices (0 .. total_out-1) to represent the pruned concatenation.
        prev_keep = torch.arange(total_out, device=device)
        # next module's first conv will use prev_keep when pruning its IN channels
        # note: we don't need to map concatenation indices back to original indices here because we physically changed
        # conv weights in-place above to expect the pruned shapes.

    # ---------- 2) Fix the final linear ----------
    # final in_features = prev_keep length after last inception
    final_channels = prev_keep.shape[0]
    # model.linear is Linear(in_features=1024 -> out)
    linear_old = model.linear
    new_linear = nn.Linear(final_channels, linear_old.out_features).to(device)
    new_linear.weight = nn.Parameter(linear_old.weight.data[:, :final_channels].clone().to(device))
    new_linear.bias   = nn.Parameter(linear_old.bias.data.clone().to(device))
    model.linear = new_linear

    print("✔ SAFE PRUNING COMPLETED for GoogLeNet (Shortcuts + FC updated)\n")




###############
###########################
